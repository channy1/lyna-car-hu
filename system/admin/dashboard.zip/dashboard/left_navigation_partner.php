<div class="page-sidebar-wrapper">
   <div class="page-sidebar navbar-collapse collapse">
        <ul class="page-sidebar-menu   " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
            <li class="nav-item start ">
                <a href="../dashboard/partner_admin.php" class="nav-link nav-toggle">
                    <i class="fa fa-dashboard"></i>
                    <span class="title">Dashboard</span>
                </a>
            </li>
            <li class="heading">
                <h3 class="uppercase">Features</h3>
            </li>
            <li class="nav-item start ">
                <a href="../dashboard/partner_admin.php" class="nav-link nav-toggle">
                    <i class="fa fa-car"></i>
                    <span class="title">Car's Owner</span>
                </a>
            </li>
            <li class="nav-item start ">
                <a href="../coupon_card/" class="nav-link nav-toggle">
                    <i class="fa fa-credit-card"></i>
                    <span class="title">Coupon Card</span>
                </a>
            </li>
        </ul>
        <!-- END SIDEBAR MENU -->
    </div>
    <!-- END SIDEBAR -->
</div>